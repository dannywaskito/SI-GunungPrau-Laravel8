<?php

 /**
  * MAKE AVATAR FUNCTION
  */




?>