
<?php $__env->startSection('title','Pendaftaran Siswa'); ?>
<?php $__env->startSection('content'); ?>
<form action="/user/insertPendaftaran" method="POST">
  <?php echo csrf_field(); ?>
<div class="container">
  <div class="row">
    <div class="col-sm">
      <div class="form-group">
        <label for="position-option">Program Pendidikan</label>
        <select class="form-control" name="education_id">
          <option value="">- Pilih Program -</option>
          <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($item->id); ?>"><?php echo e($item->education_program); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>
    <div class="col-sm">
     <div class="form-group">
      <label for="position-option">Jenis Pendaftaran</label>
      <select class="form-control" name="jenis_pendaftaran">
        <option value="">- Pilih Jenis Pendaftaran -</option>
        <option value="Baru">Siswa Baru</option>
        <option value="Pindahan">Siswa Pindahan</option>
      </select>
    </div>
  </div>
  <div class="col-sm">
   <div class="form-group">
    <label for="position-option">Sekolah Asal</label>
    <select class="form-control" name="sekolah_asal">
      <option value="">- Sekolah Asal -</option>
      <option value="asbc">Al-Azhar Syifa Budi Cibubur</option>
      <option value="bukan">Bukan Al-Azhar Syifa Budi Cibubur</option>
    </select>
  </div>
</div>
</div>
<!-- batas -->
<div class="row">
 <div class="col-sm-4">
   <div class="form-group">
    <label for="position-option">Nama Lengkap</label>
    <input type="text" class="form-control" name="nama_lengkap">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Nama Panggilan</label>
    <input type="text" class="form-control" name="nama_panggilan">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Tempat Lahir</label>
    <input type="text" class="form-control" name="tempat_lahir">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Tanggal Lahir</label>
    <input type="date" class="form-control" name="tgl_lahir">
  </div>
</div>
<div class="col-sm">
 <div class="form-group">
  <label for="position-option">Jenis Kelamin</label>
  <select class="form-control" name="jekel">
    <option value="">- Pilih -</option>
    <option value="Laki-Laki">Laki-Laki</option>
    <option value="Perempuan">Perempuan</option>
  </select>
</div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Tinggi</label>
    <input type="number" class="form-control" name="tinggi">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Berat</label>
    <input type="number" class="form-control" name="berat">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Nomor Telephone</label>
    <input type="number" class="form-control" name="phone">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Alamat</label>
    <textarea name="alamat" cols="30" class="form-control"></textarea>
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Agama</label>
    <input type="text" class="form-control" name="agama">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Anak Ke</label>
    <input type="text" class="form-control" name="anak_ke">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Dari Berapa Bersaudara</label>
    <input type="text" class="form-control" name="saudara">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Penyakit Yang pernah Diderita</label>
    <input type="text" class="form-control" name="penyakit">
  </div>
</div>
<div class="col-sm-4">
  <div class="form-group">
    <label for="position-option">Bahasa Sehari-Hari</label>
    <input type="text" class="form-control" name="bahasa">
  </div>
</div>
<div class="col-sm">
 <div class="form-group">
  <label for="position-option">Golongan Darah</label>
  <select class="form-control" name="golongan_darah">
    <option value="">- Pilih -</option>
    <option value="A">A</option>
    <option value="B">B</option>
    <option value="AB">AB</option>
    <option value="O">O</option>
  </select>
</div>
</div>
<div class="col-sm-6">
  <div class="form-group">
    <label for="position-option">Ada Saudara atau Kenalan di Al-Azhar?</label>
    <select class="form-control" data-width="100%" id="karyawan" name="karyawan_id">
      <option value="">- Pilih -</option>
      <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_karyawan); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
</div>
</div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.layouts.user-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/user/pendaftaran.blade.php ENDPATH**/ ?>