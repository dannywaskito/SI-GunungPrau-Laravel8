
<?php $__env->startSection('title','Dashboard Admin'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="jumbotron jumbotron-fluid ml-2">
      <div class="container">
        <h1 class="display-4">Test Project Laravel 8</h1>
        <p class="lead">Selamat Datang, <b><?php echo e(Auth::user()->name); ?></b></p>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\Project Laravel\testproject\resources\views/dashboard/admin/index.blade.php ENDPATH**/ ?>