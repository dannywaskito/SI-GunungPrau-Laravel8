
<?php $__env->startSection('title','Riwayat'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- <a href="/admin/add" class="btn btn-primary">Add</a> -->
    <br><br>
    <?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-check"></i> Success!</h4>
        <?php echo e(session('pesan')); ?>

    </div>
    <?php endif; ?>
    <table id="userTable" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Program Pendidikan</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; ?>
            <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($registration->user->id == Auth::user()->id): ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($registration->user->name); ?></td>
                <td><?php echo e($registration->education->education_program); ?></td>
                <td>
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($registration->id); ?>">
                        Delete
                    </button>
                </td>
            </tr>
             <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.layouts.user-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/user/riwayat.blade.php ENDPATH**/ ?>