<?php echo e($slot); ?>

<?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>