
<?php $__env->startSection('title', 'Tambah Data Karyawan'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
 <form action="/admin/insertKaryawan" method="POST">
  <?php echo csrf_field(); ?>
  <div class="content">
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label>Nama Karyawan</label>
          <input class="form-control" name="nama_karyawan" value="<?php echo e(old('nama_karyawan')); ?>">
          <div class="text-danger">
            <?php $__errorArgs = ['nama_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-group">
          <label>Kode Referral</label>
          <input class="form-control" name="kode_referral" value="<?php echo e(old('kode_referral')); ?>">
          <div class="text-danger">
            <?php $__errorArgs = ['kode_referral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-group">
          <button class="btn btn-success">Simpan</button>
          <a href="/admin/karyawan" class="btn btn-primary">Kembali</a>
        </div>
      </div>
    </div>
  </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/karyawan/v_add_karyawan.blade.php ENDPATH**/ ?>