
<?php $__env->startSection('title', 'Tambah Data Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
 <form action="/admin/insertPendidikan" method="POST">
  <?php echo csrf_field(); ?>
  <div class="content">
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label>Nama Program Pendidikan</label>
          <input class="form-control" name="program_pendidikan" value="<?php echo e(old('program_pendidikan')); ?>">
          <div class="text-danger">
            <?php $__errorArgs = ['program_pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-group">
          <button class="btn btn-success">Simpan</button>
          <a href="/admin/pendidikan" class="btn btn-primary">Kembali</a>
        </div>
      </div>
    </div>
  </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/v_add_pendidikan.blade.php ENDPATH**/ ?>