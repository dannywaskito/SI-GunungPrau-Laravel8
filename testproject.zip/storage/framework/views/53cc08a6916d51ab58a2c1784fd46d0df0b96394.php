
<?php $__env->startSection('title','Karyawan'); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Data Karyawan</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(\URL::to('/admin/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<div class="container">
    <a href="/admin/tambahkaryawan" class="btn btn-primary">Tambah Data karyawan</a>
    <br><br>
    <?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-check"></i> Success!</h4>
        <?php echo e(session('pesan')); ?>

    </div>
    <?php endif; ?>
    <table id="userTable" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Karyawan</th>
                <th>Kode Refferal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; ?>
            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->nama_karyawan); ?></td>
                <td><?php echo e($data->kode_referral); ?></td>
                <td>
                    <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#edit<?php echo e($data->id); ?>">
                        <i class="fa fa-pen"></i> Edit
                    </button>
                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id); ?>">
                        <i class="fa fa-trash"></i>
                        Hapus
                    </button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <!-- Modal Delete Karyawan -->
    <div class="modal fade" id="delete<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($data->nama_karyawan); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah anda yakin ingin menghapus data
                    <b><?php echo e($data->nama_karyawan); ?></b>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <a href="/admin/deletekaryawan/<?php echo e($data->id); ?>" class="btn btn-primary">Ya</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal Edit Data Program karyawan -->
    <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="edit<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> Ubah Data <?php echo e($data->nama_karyawan); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="/admin/ubahkaryawan">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                        <div class="form-group">
                            <label for="name">Nama karyawan</label>
                            <input type="text" name="nama_karyawan" class="form-control" value="<?php echo e($data->nama_karyawan); ?>">
                        </div>
                        <div class="form-group">
                            <label for="name">Kode Refferal</label>
                            <input type="text" name="kode_referral" class="form-control" value="<?php echo e($data->kode_referral); ?>">
                        </div>
                         <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane"></i> Ubah Data karyawan</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/karyawan/karyawan.blade.php ENDPATH**/ ?>