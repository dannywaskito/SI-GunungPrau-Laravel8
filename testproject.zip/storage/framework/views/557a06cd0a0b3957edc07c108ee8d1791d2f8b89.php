
<?php $__env->startSection('title','Settings User'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    Settings Page
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.layouts.user-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/user/settings.blade.php ENDPATH**/ ?>