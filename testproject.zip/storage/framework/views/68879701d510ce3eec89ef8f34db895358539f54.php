
<?php $__env->startSection('title','Program Pendidikan'); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Program Pendidikan</h1>
    </div>
    <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(\URL::to('/admin/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
      </ol>
  </div>
</div>
</div><!-- /.container-fluid -->
</section>

<div class="container">
    <a href="/admin/tambahPendidikan" class="btn btn-primary">Tambah Data Pendidikan</a>
    <br><br>
    <?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-check"></i> Success!</h4>
        <?php echo e(session('pesan')); ?>

    </div>
    <?php endif; ?>
    <table id="userTable" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Program Pendidikan</th>
                <th>Jenis Pendaftaran</th>
                <th>Sekolah Asal</th>
                <th>Harga Formulir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; ?>
            <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->education_program); ?></td>
                <td><?php echo e($data->type); ?></td>
                <td><?php echo e($data->school); ?></td>
                <td>Rp. <?php echo e(number_format($data->price)); ?></td>
                <td>
                    <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#edit<?php echo e($data->id); ?>">
                        <i class="fa fa-pen"></i> Edit
                    </button>
                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id); ?>">
                        <i class="fa fa-trash"></i>
                        Hapus
                    </button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <!-- Modal Delete Siswa -->
    <div class="modal fade" id="delete<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($data->education_program); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah anda yakin ingin menghapus data
                    <b><?php echo e($data->education_program); ?></b>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <a href="/admin/deletePendidikan/<?php echo e($data->id); ?>" class="btn btn-primary">Ya</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal Edit Data Program Pendidikan -->
    <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="edit<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> Ubah Data <?php echo e($data->education_program); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="/admin/ubahPendidikan">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                        <div class="form-group">
                            <label for="name">Nama Program Pendidikan</label>
                            <input type="text" name="education_program" class="form-control" value="<?php echo e($data->education_program); ?>">
                        </div>
                        <div class="form-group">
                            <strong>Jenis Pendaftaran:</strong>
                            <select name="type" class="form-control" value="<?php echo e($data->type); ?>">
                               <option <?php echo e(($data->type) == 'Siswa Baru' ? 'selected' : ''); ?>  value="Siswa Baru">Siswa Baru</option>
                                <option <?php echo e(($data->type) == 'Siswa Pindahan' ? 'selected' : ''); ?>  value="Siswa Pindahan">Siswa Pindahan</option>
                              </select>
                          </div>
                          <div class="form-group">
                            <strong>Sekolah Asal:</strong>
                            <select name="school" class="form-control" value="<?php echo e($data->school); ?>">
                               <option <?php echo e(($data->school) == 'Al-Azhar Syifa Budi Cibubur' ? 'selected' : ''); ?>  value="Al-Azhar Syifa Budi Cibubur">Al-Azhar Syifa Budi Cibubur</option>
                                <option <?php echo e(($data->school) == 'Bukan Al-Azhar Syifa Budi Cibubur' ? 'selected' : ''); ?>  value="Bukan Al-Azhar Syifa Budi Cibubur">Bukan Al-Azhar Syifa Budi Cibubur</option>
                              </select>
                          </div>
                          <div class="form-group">
                            <label for="name">Harga</label>
                            <input type="text" name="price" class="form-control" value="<?php echo e($data->price); ?>">
                        </div>
                        <button type="submit" class="btn btn-success"> Ubah</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/pendidikan/pendidikan.blade.php ENDPATH**/ ?>