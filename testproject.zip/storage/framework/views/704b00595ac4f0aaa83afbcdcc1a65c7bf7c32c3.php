
<?php $__env->startSection('title','Settings'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    Setting Page 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/settings.blade.php ENDPATH**/ ?>