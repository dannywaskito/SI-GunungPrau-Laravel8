<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>