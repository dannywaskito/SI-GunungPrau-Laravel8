
<?php $__env->startSection('title','Dashboard User'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    Selamat Datang, <?php echo e(Auth::user()->name); ?> <br>
    Anda Login Sebagai <?php echo e(Auth::user()->role='Admin'); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.layouts.user-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/user/index.blade.php ENDPATH**/ ?>