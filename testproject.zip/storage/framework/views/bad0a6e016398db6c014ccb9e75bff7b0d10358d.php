
<?php $__env->startSection('title','Dashboard Admin'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    Selamat Datang, <?php echo e(Auth::user()->name); ?> <br>
    Anda Login Sebagai <?php echo e(Auth::user()->role='Admin'); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/index.blade.php ENDPATH**/ ?>