
<?php $__env->startSection('title', 'Tambah Data Program Pendidikan'); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Tambah Data Program Pendidikan</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(\URL::to('/admin/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<div class="container">
 <form action="/admin/insertPendidikan" method="POST">
  <?php echo csrf_field(); ?>
  <div class="content">
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label>Nama Program Pendidikan</label>
          <input class="form-control" name="education_program" value="<?php echo e(old('education_program')); ?>">
          <div class="text-danger">
            <?php $__errorArgs = ['education_program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-group">
          <label>Jenis Pendaftaran</label>
          <select name="type" class="form-control">
            <option value="">- Pilih -</option>
            <option value="Siswa Baru">Siswa Baru</option>
            <option value="Siswa Pindahan">Siswa Pindahan</option>
          </select>
          <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <label>Sekolah Asal</label>
          <select name="school" class="form-control">
            <option value="">- Pilih -</option>
            <option value="Al-Azhar Syifa Budi Cibubur">Al-Azhar Syifa Budi Cibubur</option>
            <option value="Bukan Al-Azhar Syifa Budi Cibubur">Bukan Al-Azhar Syifa Budi Cibubur</option>
          </select>
          <?php $__errorArgs = ['school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <label>Harga</label>
          <input class="form-control" name="price" value="<?php echo e(old('price')); ?>">
          <div class="text-danger">
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="form-group">
    <button class="btn btn-success">Simpan</button>
    <a href="/admin/pendidikan" class="btn btn-primary">Kembali</a>
  </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/pendidikan/v_add_pendidikan.blade.php ENDPATH**/ ?>