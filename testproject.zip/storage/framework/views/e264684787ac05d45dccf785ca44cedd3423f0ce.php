
<?php $__env->startSection('title', 'Tambah Data Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
 <form action="/admin/insertAdmin" method="POST">
  <?php echo csrf_field(); ?>
  <div class="content">
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label>Nama</label>
          <input class="form-control" name="name" value="<?php echo e(old('name')); ?>">
          <div class="text-danger">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-group">
          <label>Email</label>
          <input class="form-control" name="email" value="<?php echo e(old('email')); ?>">
          <div class="text-danger">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input id="password" type="password" class="form-control" name="password" required data-eye value="<?php echo e(old('password')); ?>">
          <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="form-group">
          <label for="password-confirm">Konfirmasi Password</label>
          <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required data-eye value="<?php echo e(old('password_confirmation')); ?>">
          <span class="text-danger"><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="form-group">
          <button class="btn btn-success">Simpan</button>
          <a href="/admin/user" class="btn btn-primary">Back</a>
        </div>
      </div>
    </div>
  </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\Project Laravel\testproject\resources\views/dashboard/admin/v_add_admin.blade.php ENDPATH**/ ?>