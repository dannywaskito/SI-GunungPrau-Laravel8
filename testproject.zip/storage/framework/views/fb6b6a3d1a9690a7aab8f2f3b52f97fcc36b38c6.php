
<?php $__env->startSection('title','Program Pendidikan'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<br>
    <a href="/admin/tambahPendidikan" class="btn btn-primary">Tambah Data Pendidikan</a>
    <br><br>
    <?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-check"></i> Success!</h4>
        <?php echo e(session('pesan')); ?>

    </div>
    <?php endif; ?>
    <table id="userTable" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Program Pendidikan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; ?>
            <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->program_pendidikan); ?></td>
                <td>
                    <a href="/admin/editPendidikan/<?php echo e($data->id); ?>" class="btn btn-sm btn-primary">Ubah</a>
                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id); ?>">
                        Hapus
                    </button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        
    <!-- Modal Delete Siswa -->
    <div class="modal fade" id="delete<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($data->program_pendidikan); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah anda yakin ingin menghapus data
                    <b><?php echo e($data->program_pendidikan); ?></b>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <a href="/admin/deletePendidikan/<?php echo e($data->id); ?>" class="btn btn-primary">Yes Delete!</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\tes laravel\example-app\resources\views/dashboard/admin/pendidikan.blade.php ENDPATH**/ ?>